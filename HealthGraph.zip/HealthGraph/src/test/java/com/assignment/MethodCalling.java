package com.assignment;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MethodCalling {

	public static WebDriver driver;

	public static void getdriver() {
		WebDriverManager.chromedriver().setup();

		driver = new ChromeDriver();
	}

	public static void enterUrl(String url) {
		driver.get(url);
	}

	public static void maximizeWindow() {
		driver.manage().window().maximize();
	}

	public void elementSendys(WebElement element, String data) {
		element.sendKeys(data);

	}

	public void click(WebElement element) {

		element.click();
	}

	public String getApplicationTitle() {

		String title = driver.getTitle();

		return title;
	}

	public WebElement elementFindId(String attributeValue) {
		WebElement element = driver.findElement(By.id(attributeValue));

		return element;

	}

	public WebElement elementFindName(String attributeValue) {
		WebElement element = driver.findElement(By.name(attributeValue));

		return element;
	}

	public WebElement elementFindClassName(String attributeValue) {
		WebElement element = driver.findElement(By.className(attributeValue));

		return element;
	}

	public WebElement elementFindXpath(String xpath) {
		WebElement element = driver.findElement(By.xpath(xpath));

		return element;
	}

	public void windClose() {
		driver.close();
	}

	public void windquite() {

		driver.quit();
	}

	public String getTitle(WebElement element) {
		String text = element.getText();
		return text;

	}

	public String elementAttribute(WebElement element) {
		String attribute = element.getAttribute("value");

		return attribute;

	}

	public String elementAText(WebElement element) {
		String atext = element.getText();

		return atext;
	}

	public String getAttributeValue(WebElement element, String Attribute) {
		String attribute2 = element.getAttribute(Attribute);
		return attribute2;
	}

	public String getApplicationUrl() {
		String currentUrl = driver.getCurrentUrl();
		return currentUrl;
	}

	public void selectOptionBy(WebElement element, String text) {
		Select select = new Select(element);
		select.selectByVisibleText(text);

	}

	public void selectOptionByValue(WebElement element, String value) {
		Select select = new Select(element);
		select.selectByValue(value);
	}

	public void selectOptionByIndex(WebElement element, int index) {
		Select select = new Select(element);
		select.selectByIndex(index);
	}

	public void elementJs(WebElement element, String data) {

		JavascriptExecutor executor = (JavascriptExecutor) driver;

		executor.executeScript("agruments[0].setAttribute,('value','" + data + "')", element);
	}

	public void navActions() {
		driver.navigate().back();
	}

	public void navActi() {
		driver.navigate().refresh();
	}

	public void navAct() {
		driver.navigate().forward();
	}

	public String getWind() {

		String windowHandle = driver.getWindowHandle();

		return windowHandle;
	}

	public Set<String> getWinds() {

		Set<String> windowHandles = driver.getWindowHandles();

		return windowHandles;

	}

	public void threadWait() throws InterruptedException {
		Thread.sleep(0);

	}

	public void alertCll() {
		Alert alert = driver.switchTo().alert();
		alert.accept();

	}

	public void dismissA() {
		Alert alert1 = driver.switchTo().alert();
		alert1.dismiss();

	}

	public WebDriver frameW(String id) {
		WebDriver frame = driver.switchTo().frame(id);
		return frame;
	}

	public WebDriver frameOpen(String index) {
		WebDriver frame1 = driver.switchTo().frame(index);
		return frame1;

	}

	public WebDriver frameOpen(WebElement element) {
		WebDriver frame1 = driver.switchTo().frame(element);
		return frame1;

	}

	public WebDriver closeFrame() {
		WebDriver defaultContent = driver.switchTo().defaultContent();
		return defaultContent;

	}

	public String getDataFromExcel(String sheetname, int rowNumber, int cellNumber) throws IOException {

		String res = null;

		File file = new File("C:\\Users\\ADMIN\\eclipse-workspace\\MavenTask\\excel\\Data.xlsx");
		FileInputStream fileinputsteam = new FileInputStream(file);
		Workbook workbook = new XSSFWorkbook(fileinputsteam);
		Sheet sheet = workbook.getSheet(sheetname);
		Row row = sheet.getRow(rowNumber);
		Cell cell = row.getCell(cellNumber);
		CellType Type = cell.getCellType();

		switch (Type) {
		case STRING:
			String CellValue = cell.getStringCellValue();
			res = CellValue;

			break;

		case NUMERIC:

			if (DateUtil.isCellDateFormatted(cell)) {
				Date dateCellValue = cell.getDateCellValue();

				SimpleDateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy");

				String format = dateformat.format(dateCellValue);

				res = format;

			} else {

				double Value = cell.getNumericCellValue();
				long round = Math.round(Value);
				if (round == Value) {
					res = String.valueOf(round);

				} else {

					res = String.valueOf(Value);

				}
			}
		default:
			break;
		}

		return res;
	}

	public void updateCellData(String sheetname, int rowNumber, int cellNumber, String olDdata, String newData)
			throws IOException {

		File file = new File("C:\\Users\\ADMIN\\eclipse-workspace\\MavenTask\\excel\\Data.xlsx");
		FileInputStream fileinputsteam = new FileInputStream(file);
		Workbook workbook = new XSSFWorkbook(fileinputsteam);
		Sheet sheet = workbook.getSheet(sheetname);
		Row row = sheet.getRow(rowNumber);
		Cell cell = row.getCell(cellNumber);

		String CellValue = cell.getStringCellValue();

		if (CellValue.equals(olDdata)) {

			cell.setCellValue(newData);
		}

		FileOutputStream exit = new FileOutputStream(file);

		workbook.write(exit);
	}

	public void writeData(String sheetname, int rowNumber, int cellNumber, String Data) throws IOException {

		File file = new File("C:\\Users\\ADMIN\\eclipse-workspace\\MavenTask\\excel\\Data.xlsx");
		FileInputStream fileinputsteam = new FileInputStream(file);
		Workbook workbook = new XSSFWorkbook(fileinputsteam);
		Sheet sheet = workbook.getSheet(sheetname);
		Row row = sheet.getRow(rowNumber);
		Cell cell = row.createCell(cellNumber);
		cell.setCellValue(Data);

		FileOutputStream exit = new FileOutputStream(file);

		workbook.write(exit);

	}

	public void sendKey(WebElement element, String Data) {

		element.sendKeys(Data);

	}

	public void selectByIndex(WebElement element, int index) {
		Select select = new Select(element);
		select.selectByIndex(index);

	}

	public void selectByValues(WebElement element, String Value) {
		Select select = new Select(element);
		select.selectByValue(Value);
	}

	public void selectByText(WebElement element, String Text) {
		Select select = new Select(element);
		select.selectByVisibleText(Text);
	}

	public String Getattribute(WebElement element) {

		String attribute = element.getAttribute("value");

		return attribute;
	}

	public void click1(WebElement element) {
		element.click();

	}

	public void SelectOtptionByText(WebElement element, String text) {

		Select select = new Select(element);
		select.selectByVisibleText(text);
	}

	public void roboMeth() throws AWTException {

		Robot robot = new Robot();

		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);

	}

}
