package com.assignment;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AltoroMutual extends MethodCalling {
	public static void main(String[] args) throws AWTException, IOException {

		WebDriverManager.chromedriver().setup();

		WebDriver driver = new ChromeDriver();

		driver.navigate().to("http://altoro.testfire.net/");
		driver.manage().window().maximize();

		WebElement loginclk = driver.findElement(By.xpath("//a[@id='AccountLink']"));
		loginclk.click();

		WebElement username = driver.findElement(By.xpath("//input[@id='uid']"));
		username.sendKeys("admin@123");

		WebElement password = driver.findElement(By.xpath("//input[@id='passw']"));
		password.sendKeys("admin123");

		WebElement btnclk = driver.findElement(By.xpath("//input[@name='btnSubmit']"));
		btnclk.click();

		TakesScreenshot screenshot = (TakesScreenshot) driver;
		File s = screenshot.getScreenshotAs(OutputType.FILE);
		File d = new File("C:\\Users\\ADMIN\\eclipse-workspace\\HealthGraph\\screenshot\\output.png");
		FileUtils.copyFile(s, d);

		WebElement username1 = driver.findElement(By.xpath("//input[@id='uid']"));
		username1.sendKeys("admin");

		WebElement password1 = driver.findElement(By.xpath("//input[@id='passw']"));
		password1.sendKeys("admin");

		WebElement btnclk1 = driver.findElement(By.xpath("//input[@name='btnSubmit']"));
		btnclk1.click();

		WebElement btnclkaccount = driver.findElement(By.xpath("//a[@id='MenuHyperLink1']"));
		btnclkaccount.click();

		WebElement btnclkcorp = driver.findElement(By.xpath("//select[@id='listAccounts']"));
		btnclkcorp.click();

		WebElement clk801 = driver.findElement(By.xpath("//option[@value='800001']"));
		clk801.click();

		WebElement goclk = driver.findElement(By.xpath("//input[@id='btnGetAccount']"));
		goclk.click();

		WebElement Transferclk = driver.findElement(By.xpath("//a[@id='MenuHyperLink3']"));
		Transferclk.click();

		WebElement btnclkcorp3 = driver.findElement(By.xpath("//select[@id='toAccount']"));
		btnclkcorp3.click();

		Select select = new Select(btnclkcorp3);
		select.selectByIndex(1);

		WebElement data = driver.findElement(By.xpath("//input[@id='transferAmount']"));
		data.sendKeys("9876");

		WebElement tran1 = driver.findElement(By.xpath("//input[@name='transfer']"));
		tran1.click();
		TakesScreenshot Transfer = (TakesScreenshot) driver;
		File so = Transfer.getScreenshotAs(OutputType.FILE);
		File de = new File("C:\\Users\\ADMIN\\eclipse-workspace\\HealthGraph\\screenshot\\output1.png");
		FileUtils.copyFile(so, de);

		WebElement result = driver.findElement(By.xpath("//a[@id='MenuHyperLink2']"));
		result.click();

		TakesScreenshot history = (TakesScreenshot) driver;
		File start = history.getScreenshotAs(OutputType.FILE);
		File enD = new File("C:\\Users\\ADMIN\\eclipse-workspace\\HealthGraph\\screenshot\\output2.png");
		FileUtils.copyFile(start, enD);

		WebElement contact = driver.findElement(By.xpath("//a[@id='HyperLink3']"));
		contact.click();

		WebElement form = driver.findElement(By.xpath("//a[contains(text(),'online form')]"));
		form.click();

		WebElement emailid = driver.findElement(By.xpath("//input[@name='email_addr']"));

		JavascriptExecutor id = (JavascriptExecutor) driver;

		id.executeScript("arguments[0].value='srimugan@tester.com'", emailid);

		WebElement data1 = driver.findElement(By.xpath("//input[@name='subject']"));

		id.executeScript("arguments[0].value='TESTER'", data1);

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);

		robot.keyPress(KeyEvent.VK_T);
		robot.keyRelease(KeyEvent.VK_T);

		robot.keyPress(KeyEvent.VK_H);
		robot.keyRelease(KeyEvent.VK_H);

		robot.keyPress(KeyEvent.VK_A);
		robot.keyRelease(KeyEvent.VK_A);

		robot.keyPress(KeyEvent.VK_N);
		robot.keyRelease(KeyEvent.VK_N);

		robot.keyPress(KeyEvent.VK_K);
		robot.keyRelease(KeyEvent.VK_K);

		robot.keyPress(KeyEvent.VK_Y);
		robot.keyRelease(KeyEvent.VK_Y);

		robot.keyPress(KeyEvent.VK_O);
		robot.keyRelease(KeyEvent.VK_O);

		robot.keyPress(KeyEvent.VK_U);
		robot.keyRelease(KeyEvent.VK_U);

		WebElement last = driver.findElement(By.xpath("//input[@name='submit']"));
		last.click();

		TakesScreenshot finsh = (TakesScreenshot) driver;
		File go = finsh.getScreenshotAs(OutputType.FILE);
		File forw = new File("C:\\Users\\ADMIN\\eclipse-workspace\\HealthGraph\\screenshot\\output3.png");
		FileUtils.copyFile(go, forw);

		WebElement sign = driver.findElement(By.xpath("//a[@id='LoginLink']"));
		sign.click();

	}

}
